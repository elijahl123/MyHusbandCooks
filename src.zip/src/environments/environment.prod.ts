export const environment = {
  firebase: {
    projectId: 'my-husband-cooks',
    appId: '1:895944752629:web:232ff813487ad8b501f4bc',
    storageBucket: 'my-husband-cooks.appspot.com',
    apiKey: 'AIzaSyCUZrsx5R2H2B6T53NRNifJ5nmB6R5AWTk',
    authDomain: 'my-husband-cooks.firebaseapp.com',
    messagingSenderId: '895944752629',
    measurementId: 'G-HS49HHGPF7',
  },
  production: true
};
